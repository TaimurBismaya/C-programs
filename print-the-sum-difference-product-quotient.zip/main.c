
#include <stdio.h>

int main()
{
    int a,b,c,
    printf("Hello World");

    return 0;
}