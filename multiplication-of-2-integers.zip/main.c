

int main()
{
    int a,b,mul;
    printf("enter two numbers to multiply:");
    scanf("%d%d",&a,&b);
    printf("multiply is %d",a*b);

    return 0;
}
