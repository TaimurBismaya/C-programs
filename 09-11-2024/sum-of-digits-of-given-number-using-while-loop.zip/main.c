
#include <stdio.h>

int main()
{
	int num,rem,sum=0;
	printf("\n enter the numbder\n");
	scanf("%d",&num);
	while(num>0)
	{
		rem=num%10;
		sum=sum+rem;
		num=num/10;
	}
	printf("\n sum of the digits of given number=%d",aum);


	return 0;
}
